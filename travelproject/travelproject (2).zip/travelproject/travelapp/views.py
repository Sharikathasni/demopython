from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
def demo(request):
     return render(request,"index.html",{'obj:name'})
def addition(request):
     x=int(request.GET["no1"])
     y=int(request.GET["no2"])
     res=x+y
     return render(request,"about.html",{'result':res})